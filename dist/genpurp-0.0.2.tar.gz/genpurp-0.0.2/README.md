## Project description 

`genpurp` is a general-purpose library of utilities and extensions to the `pandas` standard library.

## Requirements


## Installation

Install with pip `pip install genpurp`

## Documentation


## License

See [LICENSE](https://github.com/hugodscarvalho/genpurp/blob/main/LICENSE)